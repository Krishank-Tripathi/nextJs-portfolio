export default function Contact() {
    return(
        <>
            Contact Component Details ....
        </>
    );
}