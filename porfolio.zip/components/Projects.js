export default function Projects() {
    return(
        <>
            Projects Component Details ....
        </>
    );
}